package com.ministere.controller;

import com.ministere.service.MinistereService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin(origins = "http://localhost:4222")
public class MinistereController {

    @Autowired
    MinistereService service;

    //@RequestMapping(value="/ministere/{nassm}", method = RequestMethod.GET)
    @GetMapping("/ministere/{nassm}")
    public boolean checkCitoyenValidity(@PathVariable String nassm){
        return service.checkCitoyenValidity(nassm);
    }

    @GetMapping("/ministere/type/{nassm}")
    public String checkTypeCitoyen(@PathVariable String nassm){
        return service.getTypeCitoyen(nassm);
    }


}


