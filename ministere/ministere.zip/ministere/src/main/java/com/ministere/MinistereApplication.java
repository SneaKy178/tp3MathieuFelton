package com.ministere;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MinistereApplication {

    public static void main(String[] args) {
        SpringApplication.run(MinistereApplication.class, args);
    }

}
