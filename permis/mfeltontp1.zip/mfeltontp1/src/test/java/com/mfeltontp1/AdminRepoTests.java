package com.mfeltontp1;

import static org.junit.jupiter.api.Assertions.*;

import com.mfeltontp1.model.Admin;
import com.mfeltontp1.repositories.AdminRepository;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import java.util.Arrays;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
@DataJpaTest
public class AdminRepoTests {

    @Autowired
    AdminRepository adminRepository;

    @BeforeAll
    public void dataTest(){
        Admin admin = new Admin();
        admin.setRole("tester");
        admin.setCourriel("toto@gmail.com"); admin.setPassword("Toto1234");
        adminRepository.saveAll(Arrays.asList(admin));
    }

    @Test
    @DisplayName("findAdminByIdUser")
    public void testId() {

        assertEquals(adminRepository.findAll().size(), 1);
    }


    @Test
    @DisplayName("findAdminByRole")
    public void testRole() {

        String role = "tester";

        assertEquals(adminRepository.findAdminByRole(role).size(), 1);
    }
}
