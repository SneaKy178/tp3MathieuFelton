package com.mfeltontp1.services;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import com.google.zxing.qrcode.QRCodeWriter;
import com.itextpdf.io.image.ImageDataFactory;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Image;
import com.itextpdf.layout.element.Paragraph;
import com.mfeltontp1.model.Citoyen;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import javax.mail.internet.MimeMessage;
import java.io.File;
import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Path;

@Service
public class SystemService {

    @Autowired
    private JavaMailSender mailSender;

    @Autowired
    private Environment environment;

    public boolean generateQR(String data, String filepath) throws Exception{
        try {
            Path path = FileSystems.getDefault().getPath(filepath);
            QRCodeWriter qr = new QRCodeWriter();
            MatrixToImageWriter.writeToPath(qr.encode(data,BarcodeFormat.QR_CODE,300, 300), "png", path);

//            MatrixToImageWriter.writeToPath(qr.encode(data,BarcodeFormat.QR_CODE,Integer.parseInt(environment.getProperty("qrCode.width")),
//                    Integer.parseInt(environment.getProperty("qrCode.height"))),
//                    environment.getProperty("qrCode.extension"), path);


            return true;

        } catch (Exception e){
            e.printStackTrace();
            return false;
        }


    }
    public boolean generatePDF(String filepath) throws Exception{
        try {
            PdfWriter writer = new PdfWriter(filepath);
            PdfDocument pdf = new PdfDocument(writer);
            Document document = new Document(pdf);

            Image image = new Image(ImageDataFactory.create("D:/Ecole/Java/information/qr.png"));

            Paragraph p = new Paragraph("Bonjour toi").add(" Voici ton code permis de sante").add(image);
            document.add(p);
            document.close();

            return true;
        } catch (Exception e){
            e.printStackTrace();
            return false;
        }

    }

    public boolean sendEmail(String mailTo,String subject,String body) throws Exception {

        try {
            MimeMessage message = mailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(message,true);

            helper.setTo(mailTo);
            helper.setSubject(subject);
            helper.setText(body);
            helper.addAttachment("QR CODE", new File("D:/Ecole/Java/information/qr.png"));
            helper.addAttachment("QR PDF", new File("D:/Ecole/Java/information/qr.pdf"));

            mailSender.send(message);

            return true;

        } catch (Exception e){
            e.printStackTrace();
            return false;
        }


    }

    public String generateDataCitoyen (Citoyen citoyen) {
        return "nassm : " + citoyen.getNassm() + "\n" +
                "prenom : " + citoyen.getPrenom() + "\n" +
                "nom : " + citoyen.getNom() + "\n" +
                "courriel : " + citoyen.getCourriel() + "\n" +
                "date creation : " + citoyen.getPermis().getDatePermis() + "\n" +
                "date expiration : " + citoyen.getPermis().getFinDatePermis() + "\n" +
                "type persmis : " + citoyen.getPermis().getTypePermis();

    }



    public boolean generateQrPdf(Citoyen citoyen) throws Exception {
        try{
            generateQR(generateDataCitoyen(citoyen),"D:/Ecole/Java/information/qr.png");
            generatePDF("D:/Ecole/Java/information/qr.pdf");
            sendEmail(citoyen.getCourriel(),"Contient le qr et le pdf",
                    "Voici le qr et pdf relie a votre compte avec l'information la plus importante");
            return  true;
        }  catch (Exception e){
            e.printStackTrace();
            return false;
        }
    }






}
