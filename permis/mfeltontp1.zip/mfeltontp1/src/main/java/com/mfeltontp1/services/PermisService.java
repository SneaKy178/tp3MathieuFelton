package com.mfeltontp1.services;


import com.mfeltontp1.model.Permis;
import com.mfeltontp1.repositories.PermisRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;



@Service
public class PermisService {

    @Autowired
    PermisRepository repository;

    //private static Logger logger = LoggerFactory.getLogger(PermisService.class);

    /*public String getCitoyenValidity(String input) {
        final String url = "http://localhost:9393/ministere/";
        RestTemplate restTemplate = new RestTemplate();
        ResponseEntity<Boolean> responseEntity = restTemplate.getForEntity(url+input,Boolean.class);

        return responseEntity.getBody().toString();
    }

    public static void main(String[] args) {
        PermisService service = new PermisService();
        logger.info(service.getCitoyenValidity("47F6A697"));
    }*/

    public Permis updateDateExpiration(Permis permis){
        permis.setFinDatePermis(permis.getFinDatePermis().plusDays(14));
        return repository.save(permis);
    }


}
