package com.mfeltontp1.repositories;

import com.mfeltontp1.model.Permis;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import javax.transaction.Transactional;
import java.time.LocalDate;
import java.util.Date;
import java.util.List;

@Repository
public interface PermisRepository extends JpaRepository<Permis, Integer> {

    public Permis findPermisByIdPermis(int id);

    public List<Permis> findPermisByTypePermis(String type);

    public List<Permis>  findPermisByDatePermisAfter(LocalDate date);
    public List<Permis>  findPermisByDatePermisBefore(LocalDate date);
    public List<Permis>  findPermisByDatePermisBetween(LocalDate date1, LocalDate date2);

    /*@Transactional
    @Modifying
    @Query("update Permis p set p.expirationValidityPermis = true where p.finValidityPermis < :date")
    int desactivePermis(@Param("data") LocalDate data);*/



}
