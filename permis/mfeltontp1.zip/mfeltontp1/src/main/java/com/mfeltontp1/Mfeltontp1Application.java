package com.mfeltontp1;




import com.mfeltontp1.services.SystemService;
import lombok.extern.java.Log;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;


@SpringBootApplication
@EnableScheduling
@Log
public class Mfeltontp1Application   {

    public static void main(String[] args) {
        SpringApplication.run(Mfeltontp1Application.class, args);
    }



}
