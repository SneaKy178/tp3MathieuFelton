package com.mfeltontp1.model;

import lombok.Data;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.time.LocalDate;
import java.util.Date;

@Entity
@Data
public class Permis implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int idPermis;

    private String typePermis;

    private LocalDate datePermis;

    private LocalDate finDatePermis;

    private String isExpired;

    private String veutRenew;

    public Permis(String typePermis){
        this.typePermis = typePermis;
        datePermis = LocalDate.now();
        finDatePermis = LocalDate.now().plusDays(15);
        isExpired = "false";
        veutRenew = "false";

    }

    public Permis(){
    }





}
