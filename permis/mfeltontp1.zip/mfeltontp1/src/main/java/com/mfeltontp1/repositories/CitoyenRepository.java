package com.mfeltontp1.repositories;

import com.mfeltontp1.model.Citoyen;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CitoyenRepository extends JpaRepository<Citoyen, Integer> {

    public Citoyen findCitoyenByIdUser(int id);

    public Citoyen findCitoyenByNassm(String nassm);

    public List<Citoyen> findCitoyenByNom(String nom);

    public List<Citoyen> findCitoyenBySexe(String sexe);

    public List<Citoyen> findCitoyenByAge(int age);

    public List<Citoyen> findCitoyenByNumTelephone(String telephone);

    public List<Citoyen> findCitoyenByVilleResidence(String villeResidence);

    public Citoyen findCitoyenByCourrielIgnoreCase(String courriel);

    public Citoyen findCitoyenByCourrielIgnoreCaseAndPassword(String login, String password);








}
