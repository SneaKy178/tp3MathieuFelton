package com.mfeltontp1.services;

import com.mfeltontp1.model.Citoyen;
import com.mfeltontp1.model.Permis;
import com.mfeltontp1.repositories.CitoyenRepository;
import com.mfeltontp1.repositories.PermisRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class CitoyenService {

    @Autowired
    CitoyenRepository repository;

    @Autowired
    PermisRepository permisRepository;

    public Citoyen login(String inputLogin, String inputPwd) {
        return repository.findCitoyenByCourrielIgnoreCaseAndPassword(inputLogin,inputPwd);
    }

    public Citoyen addCitoyen(Citoyen citoyen){
       Permis permis = addPermis(citoyen);
       citoyen.setPermis(permis);
        return repository.save(citoyen);
    }

    public Citoyen updateCitoyen(Citoyen citoyen) {
        return repository.save(citoyen);
    }

    public Permis addPermis(Citoyen citoyen){
        Permis permis = new Permis(getTypeByNassm(citoyen.getNassm()));
        return permisRepository.save(permis);
    }

    public boolean getCitoyenValidity(String nassm) {
        final String url = "http://localhost:9393/ministere/";
        RestTemplate restTemplate = new RestTemplate();
        ResponseEntity<Boolean> responseEntity = restTemplate.getForEntity(url + nassm, Boolean.class);
        return responseEntity.getBody();
    }

    public String getTypeByNassm(String nassm){
        final String url = "http://localhost:9393/ministere/type/";
        RestTemplate restTemplate = new RestTemplate();
        ResponseEntity<String> responseEntity = restTemplate.getForEntity(url + nassm, String.class);
        return responseEntity.getBody();
    }

}
