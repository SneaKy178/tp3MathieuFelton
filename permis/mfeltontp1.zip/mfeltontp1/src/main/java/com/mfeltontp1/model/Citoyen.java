package com.mfeltontp1.model;

import lombok.Data;

import javax.persistence.*;
import java.io.Serializable;



@Entity
@Data
public class Citoyen extends User implements Serializable {

    private String nom;

    private String prenom;

    private String nassm;

    private String sexe;

    private int age;

    private String numTelephone;

    private String villeResidence;

    private String isParentOuTuteur;

    private String isMineur;

    private int idParent;


    @OneToOne
    private Permis permis;


    public Citoyen() {
        super();
    }

    public Citoyen(String courriel, String password, String nom, String prenom, String nassm, String sexe, int age, String numTelephone, String villeResidence, String isParentOuTuteur, String isMineur, int idParent) {
        super(courriel, password);
        this.nom = nom;
        this.prenom = prenom;
        this.nassm = nassm;
        this.sexe = sexe;
        this.age = age;
        this.numTelephone = numTelephone;
        this.villeResidence = villeResidence;
        this.isParentOuTuteur = isParentOuTuteur;
        this.isMineur = isMineur;
        this.idParent = idParent;
    }
}
