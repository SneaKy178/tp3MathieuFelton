import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Citoyen } from 'src/app/model/citoyen';
import { PermisService } from 'src/app/services/permis.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  validMessage: string = "";
  citoyen : Citoyen;

  

  constructor(private service: PermisService, private router: Router) { }



  ngOnInit(): void {
  }

  loginForm = new FormGroup({
    courriel: new FormControl('', Validators.required),
    password: new FormControl('', Validators.required)
  });

public login(){
    this.service.login(this.loginForm.get("courriel").value, this.loginForm.get("password").value).subscribe(
      (data) => {
        if(data != null){
          this.citoyen = data;
          sessionStorage.setItem("courriel", this.loginForm.get("courriel").value);
          this.loginForm.reset();
          this.router.navigateByUrl("/dashboard", {state: this.citoyen});
        }else{
          this.validMessage = "Login or password incorrect";
        }
      }
    );
  }
    
  
}
