import { stringify } from '@angular/compiler/src/util';
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { MinistereService } from 'src/app/services/ministere.service';

@Component({
  selector: 'app-validity-nassm',
  templateUrl: './validity-nassm.component.html',
  styleUrls: ['./validity-nassm.component.css']
})
export class ValidityNassmComponent implements OnInit {
  validMessage: string = "";
  flag: boolean;

  constructor(private service: MinistereService, private router: Router) { }
  

  ngOnInit(): void {
  }

  nassmForm = new FormGroup({
    nassm: new FormControl('', Validators.required)
  });


  public onSubmit(){
    if(this.nassmForm.valid){
      this.service.checkCitizenValidity(this.nassmForm.get('nassm').value).subscribe(
        (data) => {
          this.nassmForm.reset();
          this.flag = data;
          if(this.flag) {
            this.router.navigateByUrl('/subscribe');
            this.validMessage = "Reponse of webservice call " + this.flag;
          }
        },
        (err) => {
          console.log(err);
        }
      );
    } else {
        this.validMessage = "Please fill the from before submitting!"
    }
  }


}
