import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ValidityNassmComponent } from './validity-nassm.component';

describe('ValidityNassmComponent', () => {
  let component: ValidityNassmComponent;
  let fixture: ComponentFixture<ValidityNassmComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ValidityNassmComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ValidityNassmComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
