import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Citoyen } from 'src/app/model/citoyen';
import { Permis } from 'src/app/model/permis';
import { CitoyenPermisService } from 'src/app/services/citoyen-permis.service';
import { PermisService } from 'src/app/services/permis.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  citoyen : Citoyen;
  permis : Permis;

  constructor(private service : PermisService, private permisService : CitoyenPermisService, private router : Router) { }

  ngOnInit(): void {
    this.citoyen = history.state;
    this.permis = this.citoyen.permis;
  }

  public modify(){
    this.router.navigateByUrl("/modifyCitoyen", {state: this.citoyen});
  }

  sendEmail(){
    this.service.sendEmail(this.citoyen).subscribe(
      (data) => {
        if(data) {
          alert("email has been sent");
        } else {
          alert("email has not been sent");
        } 
      }   
    );
  }

  updateDatePermis(){
    this.permisService.updatePermis(this.permis).subscribe(
      (data) => {
        if(data) {
          this.refreshData();
        } else {
          alert("Date has not been updated");
        }
      }
    )
  }

  public refreshData() {
    this.service.login(this.citoyen.courriel,this.citoyen.password).subscribe(
      (data) => {
        if(data != null) {
          this.permis = data.permis;
        } else {
          console.log("Unable to refresh")
        }
      }
    )
  }

}
