import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { PermisService } from 'src/app/services/permis.service';

@Component({
  selector: 'app-subscribe',
  templateUrl: './subscribe.component.html',
  styleUrls: ['./subscribe.component.css']
})
export class SubscribeComponent implements OnInit {

  validMessage: string = "";
  flag: boolean;
  isMineur : boolean

  constructor(private service: PermisService, private route: Router) { }

  ngOnInit(): void {
  }

  subscribeForm = new FormGroup({
    nassm: new FormControl('', Validators.required),
    courriel: new FormControl('', Validators.required),
    password: new FormControl('', Validators.required),
    prenom: new FormControl('', Validators.required),
    nom: new FormControl('', Validators.required),
    sexe: new FormControl('', Validators.required),
    age: new FormControl('', Validators.required),
    numTelephone: new FormControl('', Validators.required),
    villeResidence: new FormControl('', Validators.required),
    isParentOuTuteur: new FormControl('', Validators.required),
    isMineur: new FormControl('', Validators.required)
  });

 

  onSubscribe(){
    if (this.subscribeForm.valid){
      this.service.create(this.subscribeForm.value).subscribe(
        (data) => {
          if(data != null) {
            this.subscribeForm.reset();
          this.route.navigateByUrl('/login');
          } else {
            this.validMessage = 'cannot subscribe';
          }
        },
        (err) => {
          console.log(err);
        }
      );
    } else {
      this.validMessage = "Please fill the form";
    }
  }

}
