import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-permis-request',
  templateUrl: './permis-request.component.html',
  styleUrls: ['./permis-request.component.css']
})
export class PermisRequestComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
