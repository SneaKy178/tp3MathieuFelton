import { Permis } from "./permis";

export class Citoyen {
    idUser : number;
    courriel : string;
    password : string;

    nom : string;
    prenom : string;
    nassm : string;
    sexe : string;
    age : number;
    numTelephone : string;
    villeResidence : string;
    isParentOuTuteur : string;
    isMineur : string;
    idPermis : number;
    idParent : number;
    permis : Permis;
}
